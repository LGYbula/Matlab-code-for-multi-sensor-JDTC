function Z= gen_observation_fn(model,X)

%r/t observation equation


if isempty(X)
    Z= [];
else %modify below here for user specified measurement model
    P= X([1 3],:);
    Z(1,:)= sqrt(sum(P.^2));
    Z(2,:)= atan2(P(1,:),P(2,:));   
    Z= Z;
end