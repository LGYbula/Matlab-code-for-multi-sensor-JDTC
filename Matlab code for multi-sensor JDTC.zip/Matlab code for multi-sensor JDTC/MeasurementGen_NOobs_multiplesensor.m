function Z = MeasurementGen_NOobs_multiplesensor(NUMnode,NUMtar,TARstar,TARend,xpos,POSsensor,OBSzone,model,CLASSnode)

    % Generating measurements
    Z = cell(1,NUMnode);

    for t = 1:model.T_total
        for s=1:NUMnode

            ZD = [];
            for i = 1:NUMtar    % Measurements from targets
                if t >= TARstar(i) && t <= TARend(i)
                    if rand() <= model.Pd || 1
                        xtem = xpos{1,i}(:,t-TARstar(i)+1);
                        if CLASSnode(1,s)==1
                            ZDtar= sqrt( (xtem(1,1)-POSsensor(1,s))^2 + (xtem(3,1)-POSsensor(2,s))^2) + model.FAIr * randn();    % range TOA
                        else
                            ZDtar = atan2( xtem(3,1)-POSsensor(2,s) , xtem(1,1)-POSsensor(1,s) ) + model.FAIangle * randn();       % angle DOA
                        end
                        
                        ZD = cat(2,ZD,ZDtar);
                    end
                end
            end

            CLUTTERnum = random('Poisson',model.lambda_c);
            
            if CLUTTERnum==0
                CLUTTERnum=1;
            end
            

            if CLASSnode(1,s)==1
                ZC = (OBSzone(2,2)-OBSzone(2,1)) * rand(1,CLUTTERnum) + repmat(OBSzone(2,1),1,CLUTTERnum);
            else
                ZC = (OBSzone(1,2)-OBSzone(1,1)) * rand(1,CLUTTERnum) + repmat(OBSzone(1,1),1,CLUTTERnum);
            end
            Z{1,s}{1,t} = cat(2,ZD,ZC);
      
        end
    end
end