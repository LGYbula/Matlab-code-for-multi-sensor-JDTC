function Displayparameter = Displaypicture_tiaoshi_MS1(MODesti,Modest,Classest,OSPAdis,NUMesti,model,NUMnode)

%��ͼ����
fusion_strategy=1;
NUMfig_SUM=cell(1,fusion_strategy);
Classfig_SUM=cell(1,fusion_strategy);
Modfig_SUM=cell(1,fusion_strategy);
MODfig_SUM=cell(1,3);
OSPAfig_SUM=cell(1,fusion_strategy);

Displayparameter.OSPAfig_SUM_t=zeros(1,fusion_strategy);

for ii=1:fusion_strategy
    
    index=ii*7;
    failure_test=[];
    for tt=1:model.Montecarlo
        if mean(NUMesti(1,:,tt),2)<0.5
            failure_test=[failure_test tt];
        end
    end
    len_failure=size(failure_test,2);
    
    
    figure(index+1)
    hold on
    axis([0 model.T_total 0 1.1]);
    NUMfig_SUM{1,ii}=zeros(1,model.T_total);
    
    for tt=1:model.Montecarlo
        
        [I J]=find(tt==failure_test);
        if size(J,2)==0
            NUMmean = NUMesti(1,:,tt); %����һ����������
            NUMfig = NUMmean;%mean(NUMmean,1);
            NUMfig_SUM{1,ii}=NUMfig_SUM{1,ii}+NUMfig;
        else
            NUMfig_SUM{1,ii}=NUMfig_SUM{1,ii};
        end
        
    end
    NUMfig_SUM{1,ii}=NUMfig_SUM{1,ii}/(model.Montecarlo-len_failure);


%     NUMfig_SUM{1,ii}=NUMfig_SUM{1,ii}./1;
    h(2)=plot(1:model.T_total,NUMfig_SUM{1,ii},'LineWidth',2);
    
    
    figure(index+2)
    hold on
    axis([0 model.T_total 0 1]);
    MODfig_SUM{1,1}=zeros(1,model.T_total);
    
    for tt=1:model.Montecarlo
        [I J]=find(tt==failure_test);
        if size(J,2)==0
            MODmean=MODesti{1,1}(1,:,tt,:);
            MODfig = mean(MODmean,1);
            MODfig_SUM{1,1}=MODfig_SUM{1,1}+MODfig;
        else
            MODfig_SUM{1,1}=MODfig_SUM{1,1};
        end
    end
    
    MODfig_SUM{1,1}=MODfig_SUM{1,1}./(model.Montecarlo-len_failure);
    
    %����Ӧ���ڴ���֮��Ӧ�ý���һ����һ��
    
    for t=1:model.T_total
        MODfig_SUM{1,1}(1,t,1,:)=MODfig_SUM{1,1}(1,t,1,:)/sum(MODfig_SUM{1,1}(1,t,1,:),4);
    end

    h(1)=plot(1:model.T_total,MODfig_SUM{1,1}(1,:,1,1),'LineWidth',1);
%     h(2)=plot(1:model.T_total,MODfig_SUM{1,1}(1,:,1,2),'LineWidth',1);
%     h(3)=plot(1:model.T_total,Classfig_SUM{1,ii}(1,:,1,3),'LineWidth',1);
    legend(([h(1)]),'Model 1')
    
    
    figure(index+3)
    hold on
    axis([0 model.T_total 0 1]);
    MODfig_SUM{1,2}=zeros(1,model.T_total);
    
    for tt=1:model.Montecarlo
        [I J]=find(tt==failure_test);
        if size(J,2)==0
            MODmean=MODesti{1,2}(1,:,tt,:);
            MODfig = mean(MODmean,1);
            MODfig_SUM{1,2}=MODfig_SUM{1,2}+MODfig;
        else
            MODfig_SUM{1,2}=MODfig_SUM{1,2};
        end
    end
  
    MODfig_SUM{1,2}=MODfig_SUM{1,2}./(model.Montecarlo-len_failure);
    
    %����Ӧ���ڴ���֮��Ӧ�ý���һ����һ��
    
    for t=1:model.T_total
        MODfig_SUM{1,2}(1,t,1,:)=MODfig_SUM{1,2}(1,t,1,:)/sum(MODfig_SUM{1,2}(1,t,1,:),4);
    end

    h(1)=plot(1:model.T_total,MODfig_SUM{1,2}(1,:,1,1),'LineWidth',1);
    h(2)=plot(1:model.T_total,MODfig_SUM{1,2}(1,:,1,2),'LineWidth',1);
    h(3)=plot(1:model.T_total,MODfig_SUM{1,2}(1,:,1,3),'LineWidth',1);
    legend(([h(1),h(2),h(3)]),'Model 1','Model 2','Model 3')
    
    figure(index+4)
    hold on
    axis([0 model.T_total 0 1]);
    MODfig_SUM{1,3}=zeros(1,model.T_total);
   
    for tt=1:model.Montecarlo
        [I J]=find(tt==failure_test);
        if size(J,2)==0
            MODmean=MODesti{1,3}(1,:,tt,:);
            MODfig = mean(MODmean,1);
            MODfig_SUM{1,3}=MODfig_SUM{1,3}+MODfig;
        else
            MODfig_SUM{1,3}=MODfig_SUM{1,3};
        end
    end
    
    MODfig_SUM{1,3}=MODfig_SUM{1,3}./(model.Montecarlo-len_failure);
    
    %����Ӧ���ڴ���֮��Ӧ�ý���һ����һ��
    
    for t=1:model.T_total
        MODfig_SUM{1,3}(1,t,1,:)=MODfig_SUM{1,3}(1,t,1,:)/sum(MODfig_SUM{1,3}(1,t,1,:),4);
    end

    h(1)=plot(1:model.T_total,MODfig_SUM{1,3}(1,:,1,1),'LineWidth',1);
    h(2)=plot(1:model.T_total,MODfig_SUM{1,3}(1,:,1,2),'LineWidth',1);
    h(3)=plot(1:model.T_total,MODfig_SUM{1,3}(1,:,1,3),'LineWidth',1);
    legend(([h(1),h(2),h(3)]),'Model 1','Model 4','Model 5')
    
    
    figure(index+5)
    hold on
    axis([0 model.T_total 0 1]);
    Classfig_SUM{1,1}=zeros(1,model.T_total);
   
    for tt=1:model.Montecarlo
        [I J]=find(tt==failure_test);
        if size(J,2)==0
            Classmean=Classest(1,:,tt,:);
            Classfig = mean(Classmean,1);
            Classfig_SUM{1,1}=Classfig_SUM{1,1}+Classfig;
            
        else
            Classfig_SUM{1,1}=Classfig_SUM{1,1};
        end
    end
  
    Classfig_SUM{1,1}=Classfig_SUM{1,1}./(model.Montecarlo-len_failure);
   
    
    %����Ӧ���ڴ���֮��Ӧ�ý���һ����һ��
    
    for t=1:model.T_total
        Classfig_SUM{1,1}(1,t,1,:)=Classfig_SUM{1,1}(1,t,1,:)/sum(Classfig_SUM{1,1}(1,t,1,:),4);
    end

    h(1)=plot(1:model.T_total,Classfig_SUM{1,1}(1,:,1,1),'LineWidth',1);
    h(2)=plot(1:model.T_total,Classfig_SUM{1,1}(1,:,1,2),'LineWidth',1);
    h(3)=plot(1:model.T_total,Classfig_SUM{1,1}(1,:,1,3),'LineWidth',1);
    legend(([h(1),h(2),h(3)]),'Class 1','Class 2','Class 3')
    
    
    figure(index+6)
    hold on
    axis([0 model.T_total 0 45]);
    OSPAfig_SUM{1,ii}=zeros(1,model.T_total);
    
    
    for tt=1:model.Montecarlo
        [I J]=find(tt==failure_test);
        if size(J,2)==0
            OSPAmean = OSPAdis(1,:,tt); %����һ����������
            OSPAfig = mean(OSPAmean,1);
            OSPAfig_SUM{1,1}=OSPAfig_SUM{1,1}+OSPAfig;
        else
            OSPAfig_SUM{1,1}=OSPAfig_SUM{1,1};
        end
    end
    
    OSPAfig_SUM{1,ii}=OSPAfig_SUM{1,ii}./(model.Montecarlo-len_failure);
    
    h(2)=plot(1:model.T_total,OSPAfig_SUM{1,1},'LineWidth',2);
    
    Displayparameter.OSPAfig_SUM_t(1,1)=sum(OSPAfig_SUM{1,1},2)/model.T_total;
    
    
    figure(index+7)
    hold on
    axis([0 model.T_total 0 4]);
    Modfig_SUM{1,ii}=zeros(1,model.T_total);
  
    Modmean = Modest(1,:,:); %����һ����������
    Modfig = mean(mean(Modmean,3),1);
    Modfig_SUM{1,ii}=Modfig_SUM{1,ii}+Modfig;
    %         h(s)=plot(1:model.T_total,Modfig,'LineWidth',1);
   
    Modfig_SUM{1,ii}=Modfig_SUM{1,ii}./1;
    h(2)=plot(1:model.T_total,Modfig_SUM{1,ii},'LineWidth',2);
    
end




end

