function [outputArg1,outputArg2] = clean_GM(w_update,inputArg2)
%CLEAN_GM �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    [w_update,m_update,P_update]= gaus_prune(w_update,m_update,P_update,filter.elim_threshold);   
    [w_update,m_update,P_update]= gaus_merge(w_update,m_update,P_update,filter.merge_threshold);   
    [w_update,m_update,P_update]= gaus_cap(w_update,m_update,P_update,filter.L_max);  
end

