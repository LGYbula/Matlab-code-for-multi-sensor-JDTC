% FUNCTIONS:
%           Build a WSN with given conditions.
% PARAMETERS:
%           NUMnode: number of all nodes (including communication nodes and sensors)
%           POSnode: postion of all nodes
%           DISneighthr: maximum distance that nodes can exchange information
%           Author: Lin Gao @ 2017/11/06

function G = GeneratingWSN(NUMnode,POSnode,DISneighthr)
    G = zeros(NUMnode,NUMnode);
    DISnode = zeros(NUMnode,NUMnode);
    for i = 1:NUMnode
        for j = 1:NUMnode
           DISnode(i,j) = sqrt( (POSnode(1,i)-POSnode(1,j))^2 + (POSnode(2,i)-POSnode(2,j))^2 );
           if DISnode(i,j) <= DISneighthr
               G(i,j) = 1;
           end
        end
    end

    for i = 1:NUMnode
        Gt = G(i,:);
        [id] = find(Gt == 1);
        if size(id,2) == 1
            DISt = DISnode(i,:);
            [AA,idx] = sort(DISt,'ascend');
            G(i,idx(1,2)) = 1;
            G(idx(1,2),i) = 1;
        end
    end

    %% List the sub-connections in a Graph
    SUBcongr = cell(1,NUMnode);
    NUMcongr = 1;
    NEIid = cell(1,NUMnode);    % Id of each sensor's neighbours (including itself)
    NEInum = sum(G,2)';    % Number of each sensor's neighbours
    for i = 1:NUMnode
        NEIid{1,i} = find(G(i,:) ~= 0);
    end

    ALLOid = [];
    SUBcongr{1,1} = NEIid{1,1};
    for i = 1:NUMnode
        if size(intersect(ALLOid,i),1) == 0
            for j = 1:NUMnode
                if i ~= j
                    INTnode = intersect(NEIid{1,i},NEIid{1,j});
                    if size(INTnode,2) ~= 0     % If there are intersections of neighbors between i and j
                        MARKexi = 0;
                        SUBcongrnew = unique( cat(2,NEIid{1,i},NEIid{1,j}) );
                        for k = 1:NUMcongr
                            if size(intersect(SUBcongr{1,k},SUBcongrnew),1)*size(intersect(SUBcongr{1,k},SUBcongrnew),2) ~= 0
                                SUBcongr{1,k} = [SUBcongr{1,k},SUBcongrnew];
                                SUBcongr{1,k} = unique(SUBcongr{1,k});
                                MARKexi = 1;
                            end
                        end
                        if MARKexi == 0
                            NUMcongr = NUMcongr + 1;
                            SUBcongr{1,NUMcongr} = SUBcongrnew;
                        end
                    end
                end
            end
        end
    end

    if NUMcongr > 1    
        MARKfus = 1;
        SUBcongrmid = SUBcongr;
        while(MARKfus)
            MATRfus = zeros(NUMcongr,NUMcongr);
            for i = 1:NUMcongr
                for j = 1:NUMcongr
                    INTnode = intersect(SUBcongr{1,i},SUBcongr{1,j});
                    if size(INTnode,2) ~= 0
                        MATRfus(i,j) = 1;
                    end
                end
            end
            JUDGEmark = (MATRfus == eye(NUMcongr));
            if sum(sum(~JUDGEmark,1),2) ~= 0
                for i = 1:NUMcongr
                    MERGid = find( MATRfus(i,:) ~= 0 );
                    MERGid(MERGid==i) = [];
                    if size(MERGid,1)*size(MERGid,2) ~= 0
                        SUBconfina = SUBcongr{1,i};
                        for j = 1:size(MERGid,2)
                            SUBconfina = cat(2,SUBconfina,SUBcongr{1,MERGid(1,j)});
                        end
                        SUBconfina = unique(SUBconfina);
                        SUBcongr{1,i} = SUBconfina;
                        for j = 1:size(MERGid,2)
                            SUBcongr{1,MERGid(1,j)} = [];
                        end
                        NUMcongrmid = 0;
                        SUBcongrmid = cell(1,NUMcongr);
                        for j = 1:NUMcongr
                            if size(SUBcongr{1,j},2) ~= 0
                                NUMcongrmid = NUMcongrmid + 1;
                                SUBcongrmid{1,NUMcongrmid} = SUBcongr{1,j};
                            end
                        end
                        NUMcongr = NUMcongrmid;
                        SUBcongr = SUBcongrmid;
                        break;
                    end
                end
            else
                MARKfus = 0;
            end
        end
    end

    %% Compute minimal distance between each sub-connections and build the connections between them
    while NUMcongr > 1
        DIScongr = zeros(NUMcongr,NUMcongr);
        IDrec = cell(1,NUMcongr);
        for i = 1:NUMcongr
            IDrec{1,i} = zeros(2,NUMcongr);
            for j = 1:NUMcongr
                % Find combinations between two subsets
                DISrec = zeros(size(SUBcongr{1,i},2),size(SUBcongr{1,j},2));
                for k = 1:size(SUBcongr{1,i},2)
                    for l = 1:size(SUBcongr{1,j},2)
                        DISrec(k,l) = DISnode( SUBcongr{1,i}(1,k),SUBcongr{1,j}(1,l) );
                    end
                end
                DISrec(logical(eye(size(DISrec)))) = Inf;
                [IDx,IDy] = find(DISrec == min(min(DISrec)));
                IDx = SUBcongr{1,i}(1,IDx(1,1));
                IDy = SUBcongr{1,j}(1,IDy(1,1));
                DIScongr(i,j) = min(min(DISrec));
                if j ~= i
                    IDrec{1,i}(:,j) = [IDx;IDy];
                end
            end
        end
        DIScongr(logical(eye(size(DIScongr)))) = Inf;

        SUBcongrnex = cell(1,NUMcongr-1);
        IDmin = find(DIScongr(1,:) == min(DIScongr(1,:)));
        CONNnode = IDrec{1,1}(:,IDmin)';
        G(CONNnode(1,1),CONNnode(1,2)) = 1;
        G(CONNnode(1,2),CONNnode(1,1)) = 1;
        SUBcongrnex{1,1} = cat(2,SUBcongr{1,1},SUBcongr{1,IDmin});
        JJ = 1;
        for i = 2:NUMcongr
            if i ~= IDmin
                JJ = JJ + 1;
                SUBcongrnex{1,JJ} = SUBcongr{1,i};
            end
        end

        NUMcongr = NUMcongr - 1;
        SUBcongr = SUBcongrnex;
    end

end