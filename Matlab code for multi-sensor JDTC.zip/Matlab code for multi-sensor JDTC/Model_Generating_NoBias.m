function [F_all,Gb_all,fai_all] = Model_Generating_NoBias(T)      

    % ģ��1
    F_1 = [1 T 0 0;
           0 1 0 0;
           0 0 1 T;
           0 0 0 1];
    Gb_1 = [2*T^3/3  T^2/2  0   0;
            T^2/2    T    0   0;
            0        0  2*T^3/3  T^2/2;
            0        0  T^2/2    T];
%     fai_m1 = 0.5;
%     fai_m1 = 0.04;
%     fai_m1 = 1*10e-2; %MM filter
    fai_m1 = 1*10e-1; %JDTC filter
%     fai_m1 = 0.5*10e-1; %JDTC filter
    
    % ģ��2
    w_t = -0.10;
    F_2 = [1 sin(w_t*T)/w_t     0 -(1-cos(w_t*T))/w_t;
           0 cos(w_t*T)         0 -sin(w_t*T);
           0 (1-cos(w_t*T))/w_t 1 sin(w_t*T)/w_t;
           0 sin(w_t*T)         0 cos(w_t*T)];
    Gb_2 = [3*T^4/4  T^3/2    0   0;
            T^3/2    T^2    0   0;
            0        0  3*T^4/4  T^3/2;
            0        0  T^3/2    T^2];
%     fai_m2 = 0.75;
%     fai_m2 = 0.04;
%     fai_m2 = 1*10e-2;
    fai_m2 =1.4*10e-1; %JDTC filter
%     fai_m2 = 0.5*10e-1; %JDTC filter
    w_t = 0.15;
    F_3 = [1 sin(w_t*T)/w_t     0 -(1-cos(w_t*T))/w_t;
        0 cos(w_t*T)         0 -sin(w_t*T);
        0 (1-cos(w_t*T))/w_t 1 sin(w_t*T)/w_t;
        0 sin(w_t*T)         0 cos(w_t*T)];
    Gb_3 = Gb_2;
%     fai_m3 = 0.75;
%     fai_m3 = 0.04;
%     fai_m3 = 1*10e-2;
    fai_m3 = 1.4*10e-1; %JDTC filter
%     fai_m3 = 0.5*10e-1; %JDTC filter
    w_t = 1.0;
    F_4 = [1 sin(w_t*T)/w_t     0 -(1-cos(w_t*T))/w_t;
           0 cos(w_t*T)         0 -sin(w_t*T);
           0 (1-cos(w_t*T))/w_t 1 sin(w_t*T)/w_t;
           0 sin(w_t*T)         0 cos(w_t*T)];
    Gb_4 = Gb_2;

    fai_m4 = 1.4*10e-1; %JDTC filter
    
    w_t = -1.0;
    F_5 = [1 sin(w_t*T)/w_t     0 -(1-cos(w_t*T))/w_t;
           0 cos(w_t*T)         0 -sin(w_t*T);
           0 (1-cos(w_t*T))/w_t 1 sin(w_t*T)/w_t;
           0 sin(w_t*T)         0 cos(w_t*T)];
    Gb_5 = Gb_2;

    fai_m5 = 1.4*10e-1; %JDTC filter
    
    
    
    

    % ģ�ͻ���
    F_all = cat(3,F_1,F_2,F_3,F_4,F_5);
    Gb_all = cat(3,Gb_1,Gb_2,Gb_3,Gb_4,Gb_5);
    fai_all = [fai_m1,fai_m2,fai_m3,fai_m4,fai_m5];
    
end