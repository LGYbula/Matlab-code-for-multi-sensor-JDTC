
close all;
clear all;
clc;

rng(2);
model.Montecarlo =1;     
model.K = 1;               
model.T_total =100;        
model.MAXtar = 2;               
model.MAXGMnum = 10;             
model.Pd = 0.90;               
model.Ps = 0.99;                 
model.EPb = 0.25;              
model.THRESHOLDprun = 1e-15;     
model.THRESHOLDmerge =20; 


model.track_threshold= 0.5; 

model.cutoff=150;
model.order =1;


model.FAIr =20;                 
model.FAIangle =0.2*pi/(180);     

model.R=[model.FAIr.^2 0
         0    model.FAIangle.^2];
     
     
model.Volume_zone = pi/2 * 5000*sqrt(2);
model.clutter_inten = 4.50e-4;
model.lambda_c = model.clutter_inten * model.Volume_zone;


model.x_dim=4;
model.z_dim=2;



STATEzone = [0 5000 0 5000];       
NUMnode = 8;
POSsensor = [1000,2000,3000,4000,1800,2200,3200,4300;
           1500,2000,2300,1800,4000,3000,3200,3300];



NUMnode = size(POSsensor,2);
CLASSnode = 1*ones(1,NUMnode);



figure(1);
hold on;
axis(STATEzone);
for s = 1:NUMnode
    if CLASSnode(1,s) == 1
        h1 = plot(POSsensor(1,s),POSsensor(2,s),'bo','MarkerFaceColor','blue','MarkerSize',9);
    else
        h2 = plot(POSsensor(1,s),POSsensor(2,s),'r^','MarkerFaceColor','red','MarkerSize',9);
    end
end

run_flag=1;

OSPAdiscom = cell(1,3);    
NUMesticom = cell(1,3);    

model.T = 1;
INITIALpoint  = [4786 -6.3 3584 -60.9]';
model.F1 = [1 model.T 0 0;
    0 1 0 0;
    0 0 1 model.T ;
    0 0 0 1];

w_t = -0.10;
model.F2=[1 sin(w_t*model.T)/w_t     0 -(1-cos(w_t*model.T))/w_t;
      0 cos(w_t*model.T)         0 -sin(w_t*model.T);
      0 (1-cos(w_t*model.T))/w_t 1 sin(w_t*model.T)/w_t;
      0 sin(w_t*model.T)         0 cos(w_t*model.T)];
  
w_t = 0.15;
model.F3=[1 sin(w_t*model.T)/w_t     0 -(1-cos(w_t*model.T))/w_t;
      0 cos(w_t*model.T)         0 -sin(w_t*model.T);
      0 (1-cos(w_t*model.T))/w_t 1 sin(w_t*model.T)/w_t;
      0 sin(w_t*model.T)         0 cos(w_t*model.T)];

[model.F_all,model.Gb_all,model.fai_all] = Model_Generating_NoBias_MS(model.T);


model.Model_c=cell(1,3);
model.TP_c=cell(1,3);

model.Model_c{1,1} = [1];
model.TP_c{1,1} = [1];

model.Model_c{1,2}= [1,2,3];
model.TP_c{1,2} = [0.9 0.05 0.05;
           0.05 0.90 0.05;
           0.05 0.05 0.90];

model.Model_c{1,3} = [1,4,5];
model.TP_c{1,3}= [0.9 0.05 0.05;
           0.05 0.90 0.05;
           0.05 0.05 0.90];


model.CP=[1/3,1/3,1/3]; 

model.Mod_num=zeros(1,size(model.CP,2));
model.MP=cell(1,size(model.CP,2));
for cc=1:size(model.CP,2)
    model.Mod_num(1,cc)=size(model.Model_c{1,cc},2);
    model.MP{1,cc}=1/model.Mod_num(1,cc)*ones(1,model.Mod_num(1,cc));
end

model.Q = diag( [2.8 3.9 2.8 3.9].^2 );
% model.Q = diag( [1 1.8 1.0 1.8].^2 );

NUMtar = 1;
TARstar = 6; 
TARend = 90; 

xpos = cell(1,NUMtar);  
figure(1);
axis([0 5000 0 5000]);
hold on;

for i = 1:NUMtar
    T_last = TARend(1,i) - TARstar(1,i) + 1;
    xpos{1,i} = zeros(4,T_last);
    xpos{1,i}(:,1) = INITIALpoint(:,i);
    for t = 2:20
        xpos{1,i}(:,t) = model.F1 * xpos{1,i}(:,t-1) + sqrtm(model.fai_all(1,1)*model.Gb_all(:,:,1)+0.001*diag([1,1,1,1])) * randn(4,1);
    end
    for t = 21:45
        xpos{1,i}(:,t) = model.F2 * xpos{1,i}(:,t-1) + sqrtm(model.fai_all(1,2)*model.Gb_all(:,:,2)+0.001*diag([1,1,1,1])) * randn(4,1);
    end
    for t =46:55
        xpos{1,i}(:,t) = model.F1 * xpos{1,i}(:,t-1) + sqrtm(model.fai_all(1,1)*model.Gb_all(:,:,1)+0.001*diag([1,1,1,1])) * randn(4,1);
    end
    for t =56:T_last
        xpos{1,i}(:,t) = model.F3 * xpos{1,i}(:,t-1) + sqrtm(model.fai_all(1,3)*model.Gb_all(:,:,3)+0.001*diag([1,1,1,1])) * randn(4,1);
    end

    figure(1);
    hold on;
    h3 = plot(xpos{1,i}(1,:),xpos{1,i}(3,:),'LineWidth',2.5);
    h4 = plot(xpos{1,i}(1,1),xpos{1,i}(3,1),'gs','MarkerFaceColor','green','Markersize',10);
end
legend([h1,h3,h4],'Sensor node','Target trajectory','Target starting point');

X_ori = zeros(4,model.T_total,NUMtar);
for i = 1:NUMtar
    X_ori(:,TARstar(i):TARend(i),i) = xpos{1,i};
end
NUMtrue = zeros(1,model.T_total); 
for t = 1:model.T_total
    for i = 1:NUMtar
        if t >= TARstar(i) && t <= TARend(i)
            NUMtrue(1,t) = NUMtrue(1,t) + 1;
        end
    end
end

OBSzone = [-pi pi;0 5000*sqrt(2)];
DENclutter=1/prod(OBSzone(2,2)-OBSzone(2,1));

OSPAdis   = zeros(1,model.T_total,model.Montecarlo);
NUMesti   = zeros(1,model.T_total,model.Montecarlo);
Modesti= zeros(1,model.T_total,model.Montecarlo);
Classesti = zeros(1,model.T_total,model.Montecarlo,size(model.CP,2));

MODesti=cell(1,size(model.CP,2));
for cc=1:size(model.CP,2)
    MODesti{1,cc}=zeros(1,model.T_total,model.Montecarlo,model.Mod_num(1,cc));
end



state_rec = zeros(4,model.T_total);
tic
for tt=1:model.Montecarlo
    
    Z = MeasurementGen_NOobs_multiplesensor(NUMnode,NUMtar,TARstar,TARend,xpos,POSsensor,OBSzone,model,CLASSnode);
    
    model.GMbirnum = 1;
    model.BIASbir = [10 2 10 2]';
    model.wbir=ones(model.GMbirnum,1) / model.GMbirnum;
    model.MPbir=cell(1,size(model.CP,2));
    for cc=1:size(model.CP,2)
        if cc==1
            model.MPbir{1,cc}=[1];
        elseif cc==2
            model.MPbir{1,cc}=[0.33,0.33,0.33];
        elseif cc==3
            model.MPbir{1,cc}=[0.33,0.33,0.33];
        end
    end
    
    
    model.MIUbir = zeros(4,model.GMbirnum);
    for  ii=1:model.GMbirnum
        model.MIUbir(:,ii) = INITIALpoint(:,1) + model.BIASbir.* randn(4,1);
        model.COVbir(:,:,ii) = diag(model.BIASbir.^2);
    end
    
    
    Bernoulli=cell(1,1); 
    Bernoullistore=cell(model.T_total,1);
    
    fusion_flag=cell(1,NUMnode);
    miss_flag=cell(1,NUMnode);
    for s=1:NUMnode
        fusion_flag{1,s}=zeros(1,NUMnode);
        miss_flag{1,s}=zeros(1,NUMnode);
    end
    for t=1:model.T_total
        
        if t==72
            pause=1;
        end
        
        
        filter.elim_threshold= model.THRESHOLDprun;        
        filter.merge_threshold= model.THRESHOLDmerge;        
        filter.track_threshold= model.track_threshold;
        filter.L_max= model.MAXGMnum;
        
        MP=model.MP;
        Mod_num=model.Mod_num;
        TP=model.TP_c;
        Mod=model.Model_c;


        if t==1
            MP_birth=cell(1,size(model.CP,2));
            w_birth=cell(1,size(model.CP,2));
            m_birth=cell(1,size(model.CP,2));
            P_birth=cell(1,size(model.CP,2));
            
            for cc=1:size(model.CP,2)
                MP_birth{1,cc}=MP{1,cc};
                w_birth{1,cc}=cell(1,Mod_num(1,cc));
                m_birth{1,cc}=cell(1,Mod_num(1,cc));
                P_birth{1,cc}=cell(1,Mod_num(1,cc));
            end
            r_birth=model.EPb;
            CP_birth=model.CP;
            for cc=1:size(model.CP,2)
                for mode=1:Mod_num(1,cc)
                    for jj=1:model.GMbirnum
                        w_birth{1,cc}{1,mode}=cat(1,w_birth{1,cc}{1,mode},model.wbir(jj,1));
                    end
                    m_birth{1,cc}{1,mode}=cat(2,m_birth{1,cc}{1,mode},model.MIUbir);
                    P_birth{1,cc}{1,mode}=cat(3,P_birth{1,cc}{1,mode},model.COVbir);
                end
            end
            
            
            for cc=1:size(model.CP,2)
                for mode=1:Mod_num(1,cc)
                    Bernoulli{1,1}.w{1,cc}{1,mode}=w_birth{1,cc}{1,mode};
                    Bernoulli{1,1}.m{1,cc}{1,mode}=m_birth{1,cc}{1,mode};
                    Bernoulli{1,1}.P{1,cc}{1,mode}=P_birth{1,cc}{1,mode};
                end
                Bernoulli{1,1}.MP{1,cc}=MP_birth{1,cc};
            end
            Bernoulli{1,1}.r=r_birth;
            Bernoulli{1,1}.CP=CP_birth;
        else
            MP_birth=cell(1,size(model.CP,2));
            w_birth=cell(1,size(model.CP,2));
            m_birth=cell(1,size(model.CP,2));
            P_birth=cell(1,size(model.CP,2));
            
            for cc=1:size(model.CP,2)
                MP_birth{1,cc}=MP{1,cc};
                w_birth{1,cc}=cell(1,Mod_num(1,cc));
                m_birth{1,cc}=cell(1,Mod_num(1,cc));
                P_birth{1,cc}=cell(1,Mod_num(1,cc));
            end
            r_birth=model.EPb;
            CP_birth=model.CP;
            
            CP_predict=zeros(1,size(model.CP,2));
            MP_predict=cell(1,size(model.CP,2));
            w_predict=cell(1,size(model.CP,2));
            m_predict=cell(1,size(model.CP,2));
            P_predict=cell(1,size(model.CP,2));
            
            for cc=1:size(model.CP,2)
                MP_predict{1,cc}=zeros(1,Mod_num(1,cc));
                w_predict{1,cc}=cell(1,Mod_num(1,cc));
                m_predict{1,cc}=cell(1,Mod_num(1,cc));
                P_predict{1,cc}=cell(1,Mod_num(1,cc));
            end
            
            
            W_sum=cell(1,size(model.CP,2));
            
            for cc=1:size(model.CP,2)
                W_sum{1,cc}=zeros(1,Mod_num(1,cc));
                for mode=1:Mod_num(1,cc)
                    W_sum{1,cc}(1,mode)=sum(model.Ps*Bernoulli{1,1}.w{1,cc}{1,mode},1);
                end
            end
            
            desk1=zeros(1,size(model.CP,2));
            for cc=1:size(model.CP,2)
                desk1(1,cc)=Bernoulli{1,1}.CP(1,cc)*sum(Bernoulli{1,1}.MP{1,cc}.*W_sum{1,cc},2);
            end
            r_predict=r_birth*(1-Bernoulli{1,1}.r)+model.Ps*Bernoulli{1,1}.r;
            
            for cc=1:size(model.CP,2)
                CP_predict(1,cc)=(r_birth*CP_birth(1,cc)*(1-Bernoulli{1,1}.r)+...
                    model.Ps*Bernoulli{1,1}.r*Bernoulli{1,1}.CP(1,cc))...
                    /r_predict;
                mode_p=zeros(1,Mod_num(1,cc));
                for mode_new=1:Mod_num(1,cc)
                    for mode_old=1:Mod_num(1,cc)
                        mode_p(1,mode_new)=mode_p(1,mode_new)+TP{1,cc}(mode_old,mode_new)*Bernoulli{1,1}.MP{1,cc}(1,mode_old);
                    end
                end
                mode_p=mode_p/sum(mode_p,2);
                for mode=1:Mod_num(1,cc)
                     MP_predict{1,cc}(1,mode)=(r_birth*CP_birth(1,cc)*MP_birth{1,cc}(1,mode)*(1-Bernoulli{1,1}.r)...
                        +model.Ps*Bernoulli{1,1}.r*mode_p(1,mode)*Bernoulli{1,1}.CP(1,cc))...
                        /(r_predict*CP_predict(1,cc));
                end
                
            end
            
            
            
            for cc=1:size(model.CP,2)
                for mode=1:Mod_num(1,cc)
                    for jj=1:model.GMbirnum
                        w_birth{1,cc}{1,mode}=cat(1,w_birth{1,cc}{1,mode},model.wbir(jj,1));
                    end
                    m_birth{1,cc}{1,mode}=cat(2,m_birth{1,cc}{1,mode},model.MIUbir);
                    P_birth{1,cc}{1,mode}=cat(3,P_birth{1,cc}{1,mode},model.COVbir);
                end
            end
            
            for cc=1:size(model.CP,2)
                for mode=1:Mod_num(1,cc)
                    w_predict{1,cc}{1,mode}=cat(1,w_predict{1,cc}{1,mode},r_birth*(1-Bernoulli{1,1}.r)*CP_birth(1,cc)*MP_birth{1,cc}(1,mode)*w_birth{1,cc}{1,mode}/(r_predict*MP_predict{1,cc}(1,mode)*CP_predict(1,cc)));
                    m_predict{1,cc}{1,mode}=cat(2,m_predict{1,cc}{1,mode},m_birth{1,cc}{1,mode});
                    P_predict{1,cc}{1,mode}=cat(3,P_predict{1,cc}{1,mode},P_birth{1,cc}{1,mode});
                end
            end
            
            w_sur=cell(1,size(model.CP,2));
            m_sur=cell(1,size(model.CP,2));
            P_sur=cell(1,size(model.CP,2));
            
            for cc=1:size(model.CP,2)
                w_sur{1,cc}=cell(1,Mod_num(1,cc));
                m_sur{1,cc}=cell(1,Mod_num(1,cc));
                P_sur{1,cc}=cell(1,Mod_num(1,cc));
            end
            
            for cc=1:size(model.CP,2)
                J=Mod{1,cc};
                max_MP_num=size(J,2);
                for max_MP_index=1:max_MP_num
                    for mode_new=1:Mod_num(1,cc)
                        w_sur{1,cc}{1,mode_new} = cat(1,w_sur{1,cc}{1,mode_new},...
                            TP{1,cc}(max_MP_index,mode_new).*Bernoulli{1,1}.CP(1,cc).*Bernoulli{1,1}.MP{1,cc}(1,max_MP_index).*Bernoulli{1,1}.r.*model.Ps.*Bernoulli{1,1}.w{1,cc}{1,max_MP_index});
                        for ii=1:size(Bernoulli{1,1}.w{1,cc}{1,max_MP_index},1)
                            m_sur{1,cc}{1,mode_new} = cat(2,m_sur{1,cc}{1,mode_new},model.F_all(:,:,Mod{1,cc}(1,mode_new))*Bernoulli{1,1}.m{1,cc}{1,max_MP_index}(:,ii));
                            P_sur{1,cc}{1,mode_new}= cat(3,P_sur{1,cc}{1,mode_new},model.fai_all(1,Mod{1,cc}(1,mode_new))*model.Gb_all(:,:,Mod{1,cc}(1,mode_new))...
                                +model.F_all(:,:,Mod{1,cc}(1,mode_new))*Bernoulli{1,1}.P{1,cc}{1,max_MP_index}(:,:,ii)*model.F_all(:,:,Mod{1,cc}(1,mode_new))');
                        end
                    end
                end
            end
            
            for cc=1:size(model.CP,2)
                for mode=1:Mod_num(1,cc)
                    w_predict{1,cc}{1,mode}=cat(1,w_predict{1,cc}{1,mode},...
                        w_sur{1,cc}{1,mode}./(r_predict* MP_predict{1,cc}(1,mode)*CP_predict(1,cc))); %
                    m_predict{1,cc}{1,mode}=cat(2,m_predict{1,cc}{1,mode},m_sur{1,cc}{1,mode});
                    P_predict{1,cc}{1,mode}=cat(3,P_predict{1,cc}{1,mode},P_sur{1,cc}{1,mode});
                end
                MP_predict{1,cc}=MP_predict{1,cc}/sum(MP_predict{1,cc},2);
            end
            
            CP_predict=CP_predict/sum(CP_predict,2);
            
            r_predict=range_EP(r_predict);
            
            MP_iter=cell(1,size(model.Model_c,2));
            w_iter=cell(1,size(model.Model_c,2));
            m_iter=cell(1,size(model.Model_c,2));
            P_iter=cell(1,size(model.Model_c,2));
            
            for cc=1:size(model.Model_c,2)
                MP_iter{1,cc}=MP_predict{1,cc};
                for mode=1:size(model.Model_c{1,cc},2)
                    w_iter{1,cc}{1,mode}=w_predict{1,cc}{1,mode};
                    m_iter{1,cc}{1,mode}=m_predict{1,cc}{1,mode};
                    P_iter{1,cc}{1,mode}=P_predict{1,cc}{1,mode};
                end
            end
            r_iter=r_predict;
            CP_iter=CP_predict;
            
            MP_update=cell(1,size(model.CP,2));
            w_update=cell(1,size(model.CP,2));
            m_update=cell(1,size(model.CP,2));
            P_update=cell(1,size(model.CP,2));
            r_update=0;
            CP_update=zeros(1,size(model.CP,2));
            
            for cc=1:size(model.Model_c,2)
                MP_update{1,cc}=zeros(1,size(model.Model_c{1,cc},2));
                w_update{1,cc}=cell(1,size(model.Model_c{1,cc},2));
                m_update{1,cc}=cell(1,size(model.Model_c{1,cc},2));
                P_update{1,cc}=cell(1,size(model.Model_c{1,cc},2));
            end
            
            for i=1:NUMnode
                
                m= size(Z{1,i}{1,t},2);
                ZD=Z{1,i}{1,t};
                
                q_temp=cell(1,size(model.CP,2));
                w_temp=cell(1,size(model.CP,2));
                m_temp=cell(1,size(model.CP,2));
                P_temp=cell(1,size(model.CP,2));
                
                like_xc=cell(1,size(model.CP,2));
                like_meas=cell(1,size(model.CP,2));
                like_sum1m=cell(1,size(model.CP,2));
                like_sum2m=cell(1,size(model.CP,2));
                
                like_sum1c=zeros(1,size(model.CP,2));
                like_sum2c=zeros(1,size(model.CP,2));
                
                like_sum1c1=zeros(1,size(model.CP,2));
                like_sum2c1=zeros(1,size(model.CP,2));
                
                like_m=cell(1,size(model.CP,2));
                like_c=zeros(1,size(model.CP,2));
                
                for cc=1:size(model.CP,2)
                    q_temp{1,cc}=cell(1,Mod_num(1,cc));
                    w_temp{1,cc}=cell(1,Mod_num(1,cc));
                    m_temp{1,cc}=cell(1,Mod_num(1,cc));
                    P_temp{1,cc}=cell(1,Mod_num(1,cc));
                    
                    like_xc{1,cc}=cell(1,Mod_num(1,cc));
                    like_meas{1,cc}=cell(1,Mod_num(1,cc));
                    like_sum1m{1,cc}=zeros(1,Mod_num(1,cc));
                    like_sum2m{1,cc}=zeros(1,Mod_num(1,cc));
                    
                    like_m{1,cc}=zeros(1,Mod_num(1,cc));
                end
                
                delta_k=0;
                constant=0;
                
                if m~=0
                    for cc=1:size(model.Model_c,2)
                        for mode=1:Mod_num(1,cc)
                            [q_temp{1,cc}{1,mode},m_temp{1,cc}{1,mode},P_temp{1,cc}{1,mode}] = ...
                                ekf_update_multiple_JDTCMM_multiplesensors(ZD,POSsensor(:,i),model,m_iter{1,cc}{1,mode},P_iter{1,cc}{1,mode},CLASSnode(1,i));
                            for ell=1:m
                                w_temp{1,cc}{1,mode}=cat(1,w_temp{1,cc}{1,mode},w_iter{1,cc}{1,mode});
                                like_xc{1,cc}{1,mode}=cat(1,like_xc{1,cc}{1,mode},q_temp{1,cc}{1,mode}(:,ell)./(model.lambda_c*model.clutter_inten));
                                like_meas{1,cc}{1,mode}=cat(1,like_meas{1,cc}{1,mode},model.Pd*w_iter{1,cc}{1,mode}(:,1).*q_temp{1,cc}{1,mode}(:,ell)./(model.lambda_c*model.clutter_inten));
                            end
                            like_sum1m{1,cc}(1,mode)=sum(like_meas{1,cc}{1,mode},1);
                            like_sum2m{1,cc}(1,mode)=sum(model.Pd*w_iter{1,cc}{1,mode},1);
                            
                            like_m{1,cc}(1,mode)=1-like_sum2m{1,cc}(1,mode)+like_sum1m{1,cc}(1,mode);
                            
                            MP_update{1,cc}(1,mode)=MP_iter{1,cc}(1,mode)*like_m{1,cc}(1,mode);
                        end
                        MP_update{1,cc}=MP_update{1,cc}/sum(MP_update{1,cc},2);
                        for mode=1:Mod_num(1,cc)
                            if MP_update{1,cc}(1,mode)>1-1e-6
                                MP_update{1,cc}(1,mode)=1-1e-6;
                            elseif MP_update{1,cc}(1,mode)<1e-6
                                MP_update{1,cc}(1,mode)=1e-6;
                            end
                        end
                        MP_update{1,cc}=MP_update{1,cc}/sum(MP_update{1,cc},2);
                        
                        like_sum1c(1,cc)=sum(like_sum1m{1,cc}.*MP_iter{1,cc},2);
                        like_sum2c(1,cc)=sum(like_sum2m{1,cc}.*MP_iter{1,cc},2);
                        
                        
                        like_c(1,cc)=1-like_sum2c(1,cc)+like_sum1c(1,cc);
                        
                        CP_update(1,cc)=CP_iter(1,cc)*like_c(1,cc);
                    end
                    for cc=1:size(model.Model_c,2)
                        constant=constant+CP_update(1,cc);
                    end
                    r_update=r_iter*constant/(1-r_iter+r_iter*constant);
                end
                
                CP_update=CP_update/sum(CP_update,2);
                for cc=1:size(model.Model_c,2)
                    if CP_update(1,cc)>1-1e-36
                        CP_update(1,cc)=1-1e-36;
                    elseif CP_update(1,cc)<1e-36
                        CP_update(1,cc)=1e-36;
                    end
                end
                CP_update=CP_update/sum(CP_update,2);
                
                for cc=1:size(model.Model_c,2)
                    for mode=1:Mod_num(1,cc)
                        delta_k=(1-r_iter+r_iter*constant);
                        w_update{1,cc}{1,mode}=cat(1,w_update{1,cc}{1,mode},(1-model.Pd)*w_iter{1,cc}{1,mode}./delta_k);
                        m_update{1,cc}{1,mode}=cat(2,m_update{1,cc}{1,mode},m_iter{1,cc}{1,mode});
                        P_update{1,cc}{1,mode}=cat(3,P_update{1,cc}{1,mode},P_iter{1,cc}{1,mode});
                    end
                end
                
                for cc=1:size(model.Model_c,2)
                    for mode=1:Mod_num(1,cc)
                        delta_k2=(1-r_iter+r_iter*constant);
                        w_update{1,cc}{1,mode}=cat(1,w_update{1,cc}{1,mode},model.Pd...
                            *like_xc{1,cc}{1,mode}(:,1).*w_temp{1,cc}{1,mode}(:,1)./delta_k2);
                        for ell=1:m
                            m_update{1,cc}{1,mode}=cat(2,m_update{1,cc}{1,mode},m_temp{1,cc}{1,mode}(:,:,ell));
                            P_update{1,cc}{1,mode}=cat(3,P_update{1,cc}{1,mode},P_temp{1,cc}{1,mode});
                        end
                    end
                end
                
                for cc=1:size(model.Model_c,2)
                    for mode=1:Mod_num(1,cc)
                        w_update{1,cc}{1,mode}=w_update{1,cc}{1,mode}./sum(w_update{1,cc}{1,mode},1);
                        [w_update_temp,m_update_temp,P_update_temp]= gaus_prune(w_update{1,cc}{1,mode},m_update{1,cc}{1,mode},P_update{1,cc}{1,mode},filter.elim_threshold);
                        [w_update_temp,m_update_temp,P_update_temp]= gaus_merge(w_update_temp,m_update_temp,P_update_temp,filter.merge_threshold);
                        [w_update_temp,m_update_temp,P_update_temp]= gaus_cap(w_update_temp,m_update_temp,P_update_temp,filter.L_max);
                        
                        w_update{1,cc}{1,mode}=w_update_temp;
                        m_update{1,cc}{1,mode}=m_update_temp;
                        P_update{1,cc}{1,mode}=P_update_temp;
                        
                        w_iter{1,cc}{1,mode}=w_update{1,cc}{1,mode};
                        m_iter{1,cc}{1,mode}=m_update{1,cc}{1,mode};
                        P_iter{1,cc}{1,mode}=P_update{1,cc}{1,mode};
                    end
                end
                
                [r_update] = range_EP(r_update);
                r_iter=r_update;
                for cc=1:size(model.Model_c,2)
                    MP_iter{1,cc}=MP_update{1,cc};
                end
                
                CP_iter=CP_update;
            end
            
            Bernoulli{1,1}.w=w_update;
            Bernoulli{1,1}.m=m_update;
            Bernoulli{1,1}.P=P_update;
            Bernoulli{1,1}.r=r_update;
            Bernoulli{1,1}.MP=MP_update;
            Bernoulli{1,1}.CP=CP_update;
        end

        Bernoullistore{t,1}=Bernoulli;

  
        if Bernoulli{1,1}.r>model.track_threshold
            Classesti(1,t,tt,:)=Bernoulli{1,1}.CP;
            [~,idxc]=max(Classesti(1,t,tt,:));
            
            for cc=1:size(model.CP,2)
                MODesti{1,cc}(1,t,tt,:)=Bernoulli{1,1}.MP{1,cc};
            end
            
            
            [~,idxm]=max(Bernoulli{1,1}.MP{1,idxc});
            Modesti(1,t,tt)=idxm;
            
            [~,idx]=max(Bernoulli{1,1}.w{1,idxc}{1,idxm});
            state_rec(:,t)=mean(Bernoulli{1,1}.m{1,idxc}{1,idxm}(:,idx),2);
            NUMesti(1,t,tt)=Bernoulli{1,1}.r;
            X0 = X_ori(:,t,:);
            OSPAdis(1,t,tt) = ospa_dist(X0,state_rec(:,t),model.cutoff,model.order);
            fprintf('time: %d,EP: %d \n\n',t,Bernoulli{1,1}.r); 
        end

    end
    
end
toc
Displayparameter1 = Displaypicture_tiaoshi_MS1(MODesti,Modesti,Classesti,OSPAdis,NUMesti,model,NUMnode);

