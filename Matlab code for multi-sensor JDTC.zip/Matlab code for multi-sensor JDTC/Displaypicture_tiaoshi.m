function Displayparameter = Displaypicture_tiaoshi(MODesti,Modest,Classest,OSPAdis,NUMesti,model,NUMnode)


fusion_strategy=1;

NUMfig_SUM=cell(1,fusion_strategy);
Classfig_SUM=cell(1,fusion_strategy);
Modfig_SUM=cell(1,fusion_strategy);
MODfig_SUM=cell(1,3);
OSPAfig_SUM=cell(1,fusion_strategy);

Displayparameter.OSPAfig_SUM_t=zeros(1,fusion_strategy);

for ii=1:fusion_strategy
    
    index=ii*7;
    
    
    figure(index+1)
    hold on
    axis([0 model.T_total 0 1.1]);
    NUMfig_SUM{1,ii}=zeros(1,model.T_total);
    for s=1:NUMnode
        NUMmean = NUMesti(s,:,:);
        NUMfig = mean(mean(NUMmean,3),1);
        NUMfig_SUM{1,ii}=NUMfig_SUM{1,ii}+NUMfig;
        h(s)=plot(1:model.T_total,NUMfig,'LineWidth',1);
    end
    NUMfig_SUM{1,ii}=NUMfig_SUM{1,ii}./NUMnode;
    NUMfig_SUM{1,ii}(1,91:model.T_total)=zeros(1,10);
    h(s+1)=plot(1:model.T_total,NUMfig_SUM{1,ii},'LineWidth',2);
    
    
    figure(index+2)
    hold on
    axis([0 model.T_total 0 1]);
    MODfig_SUM{1,1}=zeros(1,model.T_total);
    for s=1:NUMnode
        MODmean=MODesti{1,1}(s,:,:,:);
        MODfig = mean(mean(MODmean,3),1);
        MODfig_SUM{1,1}=MODfig_SUM{1,1}+MODfig;
    end
    MODfig_SUM{1,1}=MODfig_SUM{1,1}./NUMnode;
    
   
    
    for t=1:90
       
        MODfig_SUM{1,1}(1,t,1,:)=MODfig_SUM{1,1}(1,t,1,:)/sum(MODfig_SUM{1,1}(1,t,1,:),4);
    end

    h(1)=plot(1:90,MODfig_SUM{1,1}(1,1:90,1,1),'LineWidth',1);
    legend(([h(1)]),'Model 1')
    
    
    figure(index+3)
    hold on
    axis([0 model.T_total 0 1]);
    MODfig_SUM{1,2}=zeros(1,model.T_total);
    for s=1:NUMnode
        MODmean=MODesti{1,2}(s,:,:,:);
        MODfig = mean(mean(MODmean,3),1);
        MODfig_SUM{1,2}=MODfig_SUM{1,2}+MODfig;
    end
    MODfig_SUM{1,2}=MODfig_SUM{1,2}./NUMnode;
    
    
    for t=1:model.T_total
        MODfig_SUM{1,2}(1,t,1,:)=MODfig_SUM{1,2}(1,t,1,:)/sum(MODfig_SUM{1,2}(1,t,1,:),4);
    end

    h(1)=plot(1:90,MODfig_SUM{1,2}(1,1:90,1,1),'LineWidth',1);
    h(2)=plot(1:90,MODfig_SUM{1,2}(1,1:90,1,2),'LineWidth',1);
    h(3)=plot(1:90,MODfig_SUM{1,2}(1,1:90,1,3),'LineWidth',1);
    legend(([h(1),h(2),h(3)]),'Model 1','Model 2','Model 3')
    
    figure(index+4)
    hold on
    axis([0 model.T_total 0 1]);
    MODfig_SUM{1,3}=zeros(1,model.T_total);
    for s=1:NUMnode
        MODmean=MODesti{1,3}(s,:,:,:);
        MODfig = mean(mean(MODmean,3),1);
        MODfig_SUM{1,3}=MODfig_SUM{1,3}+MODfig;
    end
    MODfig_SUM{1,3}=MODfig_SUM{1,3}./NUMnode;
    
    
    for t=1:model.T_total
        MODfig_SUM{1,3}(1,t,1,:)=MODfig_SUM{1,3}(1,t,1,:)/sum(MODfig_SUM{1,3}(1,t,1,:),4);
    end

    h(1)=plot(1:90,MODfig_SUM{1,3}(1,1:90,1,1),'LineWidth',1);
    h(2)=plot(1:90,MODfig_SUM{1,3}(1,1:90,1,2),'LineWidth',1);
    h(3)=plot(1:90,MODfig_SUM{1,2}(1,1:90,1,3),'LineWidth',1);
    legend(([h(1),h(2),h(3)]),'Model 1','Model 4','Model 5')
    
    
     figure(index+5)
    hold on
    axis([0 model.T_total 0 1]);
    Classfig_SUM{1,ii}=zeros(1,model.T_total);
    for s=1:NUMnode
        Classmean=Classest(s,:,:,:);
        Classfig = mean(mean(Classmean,3),1);
        Classfig_SUM{1,ii}=Classfig_SUM{1,ii}+Classfig;
    end
    Classfig_SUM{1,ii}=Classfig_SUM{1,ii}./NUMnode;
    
    
    for t=1:model.T_total
        Classfig_SUM{1,ii}(1,t,1,:)=Classfig_SUM{1,ii}(1,t,1,:)/sum(Classfig_SUM{1,ii}(1,t,1,:),4);
    end

    h(1)=plot(1:90,Classfig_SUM{1,ii}(1,1:90,1,1),'LineWidth',1);
    h(2)=plot(1:90,Classfig_SUM{1,ii}(1,1:90,1,2),'LineWidth',1);
    h(3)=plot(1:90,Classfig_SUM{1,ii}(1,1:90,1,3),'LineWidth',1);
    legend(([h(1),h(2),h(3)]),'Class 1','Class 2','Class 3')
    
    
    figure(index+6)
    hold on
    axis([0 model.T_total 0 150]);
    OSPAfig_SUM{1,ii}=zeros(1,model.T_total);
    for s=1:NUMnode
        OSPAmean = OSPAdis(s,:,:); 
        OSPAfig = mean(mean(OSPAmean,3),1);
        OSPAfig_SUM{1,ii}=OSPAfig_SUM{1,ii}+OSPAfig;
    end
    OSPAfig_SUM{1,ii}=OSPAfig_SUM{1,ii}./NUMnode;
    OSPAfig_SUM{1,ii}(1,91:model.T_total,1)=zeros(1,10,1);
    h(s+1)=plot(1:model.T_total,OSPAfig_SUM{1,ii}(1,:,1),'LineWidth',2);
    
    Displayparameter.OSPAfig_SUM_t(1,ii)=sum(OSPAfig_SUM{1,ii},2)/model.T_total;
    
    
    figure(index+7)
    hold on
    axis([0 model.T_total 0 4]);
    Modfig_SUM{1,ii}=zeros(1,model.T_total);
    for s=1:NUMnode
        Modmean = Modest(s,:,:); 
        Modfig = mean(mean(Modmean,3),1);
        Modfig_SUM{1,ii}=Modfig_SUM{1,ii}+Modfig;
    end
    Modfig_SUM{1,ii}=Modfig_SUM{1,ii}./NUMnode;
    h(s+1)=plot(1:90,Modfig_SUM{1,ii}(1,1:90,1),'LineWidth',2);
    
end




end

