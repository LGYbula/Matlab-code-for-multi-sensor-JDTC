function [qz_update,m_update,P_update] = ekf_update_multiple_JDTCMM_multiplesensors(z,POSsensor,model,m,P,CLASSnode)

plength= size(m,2);
zlength= size(z,2);


qz_update= zeros(plength,zlength);
m_update = zeros(model.x_dim,plength,zlength);
P_update = zeros(model.x_dim,model.x_dim,plength);

for idxp=1:plength
        [qz_temp,m_temp,P_temp] = ekf_update_single(z,POSsensor,model,m(:,idxp),P(:,:,idxp),CLASSnode);
       qz_update(idxp,:)   = qz_temp;
        m_update(:,idxp,:) = m_temp;
        P_update(:,:,idxp) = P_temp;
end

function [qz_temp,m_temp,P_temp] = ekf_update_single(z,POSsensor,model,m,P,CLASSnode)


tx = m(1,1); ty = m(3,1);
STAdis = sqrt( (tx-POSsensor(1))^2+(ty-POSsensor(2))^2 );
SQUdis = (tx-POSsensor(1))^2 + (ty-POSsensor(2))^2;
HH = zeros(1,4);

if CLASSnode==1
    HH(1,1) = (tx-POSsensor(1)) / STAdis;       HH(1,3) = (ty-POSsensor(2)) / STAdis;
    RR = model.FAIr^2;
    eta = sqrt( (m(1,1)-POSsensor(1))^2 + (m(3,1)-POSsensor(2))^2 );
else
    HH(2,1) = - (ty-POSsensor(2)) / SQUdis;     HH(2,3) = (tx-POSsensor(1)) / SQUdis;
    RR = model.FAIangle^2;
    eta = atan2( m(3,1)-POSsensor(2),m(1,1)-POSsensor(1) );
end



SS = HH * P * HH' + RR;
SS = (SS+SS')/2;
Vs = chol(SS); 

det_S = prod(diag(Vs))^2; 
inv_sqrt_S = inv(Vs); 
iS = inv_sqrt_S*inv_sqrt_S';
KK = P * HH' * iS;

for ii=1:size(z,2)
    qz_temp(ii,1)= 1 / sqrt(det(2*pi*SS)) * exp( -0.5*(z(:,ii)-eta)'*iS*(z(:,ii)-eta) ) + 1e-299;
end

Zdiff = (z-eta);

%�����Ϊ�˵���һ�²�����
if CLASSnode==2
    if abs(Zdiff(1,:)) > pi
        if Zdiff(1,:) > 0
            Zdiff(1,:) = 2*pi - Zdiff(1,:);
        else
            Zdiff(1,:) = -2*pi - Zdiff(1,:);
        end
    end
end


m_temp = m + KK * Zdiff; 
P_temp = ( eye(4)-KK*HH ) * P;





