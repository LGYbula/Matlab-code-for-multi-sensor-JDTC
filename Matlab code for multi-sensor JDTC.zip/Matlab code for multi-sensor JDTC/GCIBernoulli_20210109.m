function Bernoulli = GCIBernoulli_20210109(Bernoulli,NEInum,NEIid,NUMnode,t,model)

for k=1:model.K
    Bernoullicons = Bernoulli;
   
    for s=1:NUMnode
        for i=1:NEInum(1,s)    
            Nid = NEIid{1,s}(1,i);

            CONwei = 0.5*ones(1,2);
            CLASSs = Bernoullicons{1,s}.CP .^ CONwei(1,1);
            CLASSn = Bernoulli{1,Nid}.CP .^ CONwei(1,2);
            

            WEI_sm=cell(1,size(model.Model_c,2));
            MP_sm=cell(1,size(model.Model_c,2));
            MIU_sm=cell(1,size(model.Model_c,2));
            COV_sm=cell(1,size(model.Model_c,2));
            
            for cc=1:size(model.Model_c,2)
                WEI_sm{1,cc}=cell(1,size(model.Model_c{1,cc},2));
                MP_sm{1,cc}=zeros(1,size(model.Model_c{1,cc},2));
                MIU_sm{1,cc}=cell(1,size(model.Model_c{1,cc},2));
                COV_sm{1,cc}=cell(1,size(model.Model_c{1,cc},2));
            end
            
            WEI_nm=cell(1,size(model.Model_c,2));
            MP_nm=cell(1,size(model.Model_c,2));
            MIU_nm=cell(1,size(model.Model_c,2));
            COV_nm=cell(1,size(model.Model_c,2));
            
            for cc=1:size(model.Model_c,2)
                WEI_nm{1,cc}=cell(1,size(model.Model_c{1,cc},2));
                MP_nm{1,cc}=zeros(1,size(model.Model_c{1,cc},2));
                MIU_nm{1,cc}=cell(1,size(model.Model_c{1,cc},2));
                COV_nm{1,cc}=cell(1,size(model.Model_c{1,cc},2));
            end
            
            for cc=1:size(model.Model_c,2)
                MP_sm{1,cc}=Bernoullicons{1,s}.MP{1,cc}.^ CONwei(1,1);
                MP_nm{1,cc}=Bernoulli{1,Nid}.MP{1,cc}.^ CONwei(1,2);
                for mode=1:size(model.Model_c{1,cc},2)
                    WEI_sm{1,cc}{1,mode}=Bernoullicons{1,s}.w{1,cc}{1,mode}(:,1).^ CONwei(1,1);
                    WEI_nm{1,cc}{1,mode}=Bernoulli{1,Nid}.w{1,cc}{1,mode}(:,1).^ CONwei(1,2);
                    
                    MIU_sm{1,cc}{1,mode}=Bernoullicons{1,s}.m{1,cc}{1,mode};
                    MIU_nm{1,cc}{1,mode}=Bernoulli{1,Nid}.m{1,cc}{1,mode};
                    
                    COV_sm{1,cc}{1,mode}=Bernoullicons{1,s}.P{1,cc}{1,mode};
                    COV_nm{1,cc}{1,mode}=Bernoulli{1,Nid}.P{1,cc}{1,mode};
                end
            end
            
            INTENs=Bernoullicons{1,s}.r;
            INTENn=Bernoulli{1,Nid}.r;

            
            MP_c = cell(1,size(model.Model_c,2));
            WEI_c = cell(1,size(model.Model_c,2));  
            MIU_c = cell(1,size(model.Model_c,2));
            COV_c = cell(1,size(model.Model_c,2));
            CLASSc= zeros(1,size(model.Model_c,2));
            for cc=1:size(model.Model_c,2)
                MP_c{1,cc}=zeros(1,size(model.Model_c{1,cc},2));
                for mode=1:size(model.Model_c{1,cc},2)
                    WEI_c{1,cc}{1,mode}=[];
                    MIU_c{1,cc}{1,mode}=[];
                    COV_c{1,cc}{1,mode}=[];
                end
            end
            
            
            class_wei=zeros(1,size(model.Model_c,2));
            
            for cc=1:size(model.Model_c,2)
                for mode=1:size(model.Model_c{1,cc},2)
                    for j = 1:size(WEI_sm{1,cc}{1,mode},1)
                        for l = 1:size(WEI_nm{1,cc}{1,mode},1)
                            COVct_csn = pinv( CONwei(1,1)*pinv(COV_sm{1,cc}{1,mode}(:,:,j)) + CONwei(1,2)*pinv(COV_nm{1,cc}{1,mode}(:,:,l)) );
                            MIUct_csn = COVct_csn * ( CONwei(1,1)*pinv(COV_sm{1,cc}{1,mode}(:,:,j))*MIU_sm{1,cc}{1,mode}(:,j) + CONwei(1,2)*pinv(COV_nm{1,cc}{1,mode}(:,:,l))*MIU_nm{1,cc}{1,mode}(:,l) );
                            TERM1_csn = sqrt( det(2*pi*COV_sm{1,cc}{1,mode}(:,:,j)/CONwei(1,1)) / ( det(2*pi*COV_sm{1,cc}{1,mode}(:,:,j))^(CONwei(1,1)) ) );
                            TERM2_csn = sqrt( det(2*pi*COV_nm{1,cc}{1,mode}(:,:,l)/CONwei(1,2)) / ( det(2*pi*COV_nm{1,cc}{1,mode}(:,:,l))^(CONwei(1,2)) ) );
                            COVw = COV_sm{1,cc}{1,mode}(:,:,j)/CONwei(1,1) + COV_nm{1,cc}{1,mode}(:,:,l)/CONwei(1,2);
                            TERM3_csn = 1/(sqrt(det(2*pi*COVw))) * exp( -0.5*(MIU_sm{1,cc}{1,mode}(:,j)-MIU_nm{1,cc}{1,mode}(:,l))'*pinv(COVw)*(MIU_sm{1,cc}{1,mode}(:,j)-MIU_nm{1,cc}{1,mode}(:,l)) );
                            WEIct_csn = WEI_sm{1,cc}{1,mode}(j,1) * WEI_nm{1,cc}{1,mode}(l,1) * TERM1_csn * TERM2_csn * TERM3_csn + 1e-99;
                            WEI_c{1,cc}{1,mode} = cat(1,WEI_c{1,cc}{1,mode},WEIct_csn);
                            MIU_c{1,cc}{1,mode} = cat(2,MIU_c{1,cc}{1,mode},MIUct_csn);
                            COV_c{1,cc}{1,mode} = cat(3,COV_c{1,cc}{1,mode},COVct_csn);
                        end
                    end

                  MP_c{1,cc}(1,mode)=sum(MP_sm{1,cc}(1,mode)*MP_nm{1,cc}(1,mode)*WEI_c{1,cc}{1,mode},1);

                end
                
                  MP_c{1,cc}=MP_c{1,cc}/sum(MP_c{1,cc},2);
                  for mode=1:size(model.Model_c{1,cc},2)
                      if MP_c{1,cc}(1,mode)>1-1e-15
                          MP_c{1,cc}(1,mode)=1-1e-15;
                      elseif MP_c{1,cc}(1,mode)<1e-15
                          MP_c{1,cc}(1,mode)=1e-15;
                      else
                          MP_c{1,cc}(1,mode)=MP_c{1,cc}(1,mode);
                      end
                  end
                  MP_c{1,cc}=MP_c{1,cc}/sum(MP_c{1,cc},2);
                  
                  
                for mode=1:size(model.Model_c{1,cc},2)
                    class_wei(1,cc)=class_wei(1,cc)+sum(MP_c{1,cc}(1,mode)*WEI_c{1,cc}{1,mode},1);
                end
                CLASSc(1,cc)=CLASSs(1,cc)*CLASSn(1,cc)*class_wei(1,cc);
            end
            
            CLASSc=CLASSc/sum(CLASSc,2);
            
            for cc=1:size(model.Model_c,2)
                if CLASSc(1,cc)>1-1e-15
                    CLASSc(1,cc)=1-1e-15;
                elseif CLASSc(1,cc)<1e-15
                    CLASSc(1,cc)=1e-15;
                else
                    CLASSc(1,cc)=CLASSc(1,cc);
                end
            end
            
            CLASSc=CLASSc/sum(CLASSc,2);


            Bernoullicons{1,s}.r=INTENs^(CONwei(1,1))*INTENn^(CONwei(1,2))*sum(CLASSc,2) /...
                (INTENs^(CONwei(1,1))*INTENn^(CONwei(1,2))*sum(CLASSc,2) + (1-INTENs)^(CONwei(1,1))*(1-INTENn)^(CONwei(1,2)));
            [Bernoullicons{1,s}.r] = range_EP(Bernoullicons{1,s}.r);
            
            
            if ~(isreal( Bernoullicons{1,s}.r))
                pause=1;
            end
           
        

            for cc=1:size(model.Model_c,2)
                for mode=1:size(model.Model_c{1,cc},2)
                    WEI_c{1,cc}{1,mode}= WEI_c{1,cc}{1,mode}/sum( WEI_c{1,cc}{1,mode},1);
                    
                    [WEI_update_temp,MIU_update_temp,COV_update_temp]= gaus_prune(WEI_c{1,cc}{1,mode},MIU_c{1,cc}{1,mode},COV_c{1,cc}{1,mode},model.THRESHOLDprun);
                    [WEI_update_temp,MIU_update_temp,COV_update_temp]= gaus_merge(WEI_update_temp,MIU_update_temp,COV_update_temp,model.THRESHOLDmerge);
                    [WEI_update_temp,MIU_update_temp,COV_update_temp]= gaus_cap(WEI_update_temp,MIU_update_temp,COV_update_temp,model.MAXGMnum);
                    
                    WEI_c{1,cc}{1,mode}=WEI_update_temp;
                    MIU_c{1,cc}{1,mode}=MIU_update_temp;
                    COV_c{1,cc}{1,mode}=COV_update_temp;
                end

            end
            
            Bernoullicons{1,s}.MP=MP_c;
            Bernoullicons{1,s}.w=WEI_c;
            Bernoullicons{1,s}.m=MIU_c;
            Bernoullicons{1,s}.P=COV_c;
 
            Bernoullicons{1,s}.CP=CLASSc;
        end
    end
    Bernoulli=Bernoullicons;
    
end
end

