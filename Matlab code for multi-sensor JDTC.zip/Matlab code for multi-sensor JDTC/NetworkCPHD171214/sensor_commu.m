clear all
clc

NUMsensor=20;
NUMcommu=0;
POSsensor = zeros(2,NUMsensor);
POScommu = zeros(2,NUMcommu);
ZONEaxis = [0 5000 0 5000];
for i = 1:NUMsensor
    POSsensor(1,i) = (ZONEaxis(2) - ZONEaxis(1))*rand() + ZONEaxis(1);
    POSsensor(2,i) = (ZONEaxis(4) - ZONEaxis(3))*rand() + ZONEaxis(1);
    figure(1);
    hold on;
    if i <= NUMsensor / 2
        plot(POSsensor(1,i),POSsensor(2,i),'r^','MarkerFaceColor','red','MarkerSize',9);
    else
        plot(POSsensor(1,i),POSsensor(2,i),'ro','MarkerFaceColor','m','MarkerSize',9);
    end
end
for i = 1:NUMcommu
    POScommu(1,i) = (ZONEaxis(2) - ZONEaxis(1))*rand() + ZONEaxis(1);
    POScommu(2,i) = (ZONEaxis(4) - ZONEaxis(3))*rand() + ZONEaxis(1);
    plot(POScommu(1,i),POScommu(2,i),'bs','MarkerFaceColor','blue','MarkerSize',9);
end

save POSsensor