clear all
clc

load POSsensor
NUMnode=20;
DISneighthr=700; %1000
G = GeneratingWSN(NUMnode,POSsensor,DISneighthr);
save G
